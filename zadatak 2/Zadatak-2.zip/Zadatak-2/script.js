

function generate() {
  const grid = document.getElementById("grid");

  const searchParams = new URLSearchParams(window.location.search); //izvlacenje broja redova i kolona iz adrese
  x = searchParams.get('m'); // row
  y = searchParams.get('n'); // col

  //da li su vrednosti validne
  if (isNaN(x) || isNaN(y) || x < 3 || y < 3 ) {
    alert('Broj treba da bude veci od 3');
    return;
  }

//crtanje matrice
  for (let i = 0; i < x; i++) {
    
    var row = document.createElement('div');
    row.setAttribute("id", "ROW");

    var rowMark = document.createElement('span');
    rowMark.setAttribute("id", "ROW-MARK");
    rowMark.innerText = 'Red ' + i;

    for (let j = 0; j < y; j++) {
      var col = document.createElement('div');
      col.setAttribute("id", "COL");
      col.innerText = i + '-' + j;
      row.appendChild(col);
      col.onclick = selectSeat();
    }
    grid.appendChild(rowMark);
    grid.appendChild(row);

  }
  
  function selectSeat(){
    // alert( i + '-' + j); 
    // let left = document.getElementById(i + '-' + j-1);
    // let right = document.getElementById(i + '-' + j+1);
    //   left.classList.add('selectable');
    //   right.classList.add('selectable');
      console.log(1);

    //sledeci klik mora da bude levo ili desno od selektovanog //// zabraniti klik na sva polja osim levog i desnog
  }

}

